
function preload() {
    //carregue as imagens aqui
}

function setup(){
    createCanvas(1000,800);
    //crie os sprites de gato e rato aqui
    
}

function draw() {

    background(255);
    //Escreva a condição aqui para avaliar se o gato e o rato colidem
    drawSprites();
}


function keyPressed(){

  //Para mover e alterar a animação, escreva o código aqui


}
